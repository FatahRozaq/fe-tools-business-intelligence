const config = {
    API_BASE_URL: "http://127.0.0.1:8000"
    // API_BASE_URL: "https://be-tools-visualisasi-data-273711029632.asia-southeast2.run.app"
};
  
export default config;
  